sap.ui.define([
	"md2/md2/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"md2/md2/model/formatter",
	"sap/m/MessageToast",
	"sap/ui/comp/smarttable/SmartTable",
	"sap/ui/comp/smartfilterbar/SmartFilterBar",
	"sap/m/OverflowToolbar",
	"sap/m/ToolbarSpacer",
	"sap/m/OverflowToolbarButton",
	"sap/m/OverflowToolbarToggleButton",
	"sap/m/ObjectStatus",
	"sap/m/Button",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, formatter, MessageToast, SmartTable, SmartFilterBar, OverflowToolbar, ToolbarSpacer,
	OverflowToolbarButton, OverflowToolbarToggleButton, ObjectStatus, Button, Filter, FilterOperator, Fragment, MessageBox) {
	"use strict";

	return BaseController.extend("md2.md2.controller.Detail", {

		formatter: formatter,
		_mFilters: {
			activeVersion: new Filter("Version", FilterOperator.NE, "D"),
			deactiveVersion: new Filter("Version", FilterOperator.EQ, "D")
		},

		_oViewModel: new JSONModel({
			button: {
				visible: {
					Create: true,
					Update: true,
					DeactivateDelete: true,
					Restore: true,
					Refresh: true,
					Copy: true,
					ChangeSelectionMode: true,
					ChangeVersionMode: true
				},
				pressed: {
					ChangeSelectionMode: false,
					ChangeVersionMode: false
				}
			},
			table: {
				selectionMode: "Single",
				selectedItemsCount: 0
			},
			dialog: {
				title: "",
				inputValue: "",
				mode: "",
				updatePath: "",
				label: "",
				nameField: "",
				idField: ""
			}
		}),

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(this._oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		// onListUpdateFinished: function(oEvent) {
		// 	var sTitle,
		// 		iTotalItems = oEvent.getParameter("total"),
		// 		oViewModel = this.getModel("detailView");

		// 	// only update the counter if the length is final
		// 	if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
		// 		if (iTotalItems) {
		// 			sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
		// 		} else {
		// 			//Display 'Line Items' instead of 'Line items (0)'
		// 			sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
		// 		}
		// 		oViewModel.setProperty("/lineItemListTitle", sTitle);
		// 	}
		// },

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sEntity = oEvent.getParameter("arguments").entity;
			this.getModel().metadataLoaded().then(function() {
				this.byId("thDetail").setText(this.getModel("i18n").getResourceBundle().getText("t" + sEntity));
				this._loadTable(sEntity);
				this.getModel("detailView").setProperty("/dialog/idField", this._oSmartTable.getEntitySet().slice(16, -1) + "ID");
				this.getModel("detailView").setProperty("/dialog/nameField", this._oSmartTable.getEntitySet().slice(16, -1) + "Text");
			}.bind(this));
		},
		onPressChangeSelectionMode: function(oEvent) {
			this.getModel("detailView").setProperty("/table/selectionMode", oEvent.getParameter("pressed") ? "Multi" : "Single");
			oEvent.getParameter("pressed") ? MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastMultiSelectON")) :
				MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastMultiSelectOFF"));
		},
		onPressDeactivateMode: function(oEvent) {
			this._oSmartTable.rebindTable();
			oEvent.getParameter("pressed") ? MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastDeactivatedGoods")) :
				MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastActivatedGoods"));

		},
		onPressDelete: function(oEvent) {
			var that = this;
			var aSelectedContext = this._oTable.getSelectedIndices().map(function(iSelectedIndex) {
				return this._oTable.getContextByIndex(iSelectedIndex);
			}.bind(this));
			if (this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode")) {
				MessageBox.confirm(this.getModel("i18n").getResourceBundle().getText("msgConfirmDelete"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aSelectedContext.forEach(function(oContext) {
								that.getModel().remove(oContext.getPath(), {
									success: function() {
										MessageToast.show(that.getModel("i18n").getResourceBundle().getText("msgSuccessDelete"));
									}
								});
							});
						}
					}
				});
			} else {
				MessageBox.confirm(this.getModel("i18n").getResourceBundle().getText("msgConfirmDeactivate"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aSelectedContext.forEach(function(oContext) {
								that.getModel().setProperty(oContext.getPath() + "/Version", "D");
							});
							that.getModel().submitChanges({
								success: function() {
									MessageToast.show(that.getModel("i18n").getResourceBundle().getText("msgSuccessDeactivate"));
								}
							});
						}
					}
				});
			}
		},
		onPressRestore: function(oEvent) {
			var that = this;
			var aSelectedContext = this._oTable.getSelectedIndices().map(function(iSelectedIndex) {
				return this._oTable.getContextByIndex(iSelectedIndex);
			}.bind(this));

			if (this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode")) {
				MessageBox.confirm(this.getModel("i18n").getResourceBundle().getText("msgConfirmRestore"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aSelectedContext.forEach(function(oContext) {
								that.getModel().setProperty(oContext.getPath() + "/Version", "A");
							});
							that.getModel().submitChanges({
								success: function() {
									MessageToast.show(that.getModel("i18n").getResourceBundle().getText("msgSuccessRestore"));
								}
							});
						}
					}
				});
			}

		},
		onPressAdd: function(oEvent) {
			this.onOpenDialog();
			MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tDialogCreate"));

		},
		onPressRefresh: function(oEvent) {
			this._oSmartTable.rebindTable(true);
			MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msgRefreshTable"));
		},

		_getAddEditDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("md2.md2.view.fragments.AddEditDialog", this);

				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		onOpenDialog: function() {
			this._getAddEditDialog().open();
		},
		onPressCancelDialog: function() {
			this._getAddEditDialog().close();
			MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tDialogCanceled"));
		},
		_loadTable: function(sEntity) {

			this._oSmartFilterBar = new SmartFilterBar({
				id: "sf" + sEntity,
				entitySet: "zjblessons_base_" + sEntity,
				liveMode: true,
				enableBasicSearch: false,
				useToolbar: true
			});
			var aToolbarButtons = [

				new OverflowToolbarToggleButton({
					enabled: true,
					visible: "{detailView>/button/visible/ChangeSelectionMode}",
					text: "{i18n>tMultiSelectToogleButton}",
					type: "Default",
					icon: "{i18n>iMultiSelect}",
					press: this.onPressChangeSelectionMode.bind(this),
					pressed: "{detailView>/button/pressed/ChangeSelectionMode}",
					tooltip: "{i18n>tButtonTipMultiselectMode}"
				}),
				new OverflowToolbarToggleButton({
					enabled: true,
					visible: "{detailView>/button/visible/ChangeVersionMode}",
					text: "{i18n>tShowDeactivatedButton}",
					type: "Reject",
					icon: "{i18n>iCircle1}",
					activeIcon: "{i18n>iActive}",
					press: this.onPressDeactivateMode.bind(this),
					pressed: "{detailView>/button/pressed/ChangeVersionMode}",
					tooltip: "{i18n>tButtonTipDeactivateMode}"
				}),
				new ToolbarSpacer(),

				new Button({
					enabled: "{detailView>/button/pressed/ChangeVersionMode}",
					visible: "{detailView>/button/pressed/ChangeVersionMode}",
					text: "",
					type: "Default",
					icon: "{i18n>iRestore}",
					tooltip: "{i18n>tButtonTipRestore}",
					press: this.onPressRestore.bind(this)
				}),
				new Button({
					enabled: "{= !${detailView>/button/pressed/ChangeVersionMode}}",
					visible: "{= !${detailView>/button/pressed/ChangeVersionMode}}",
					text: "",
					type: "Default",
					icon: "{i18n>iAdd}",
					tooltip: "{i18n>tButtonTipAdd}",
					press: this.onPressAdd.bind(this)
				}),
				new Button({
					enabled: true,
					visible: true,
					text: "",
					type: "Default",
					icon: "{i18n>iDelete}",
					tooltip: "{i18n>tButtonTipDelete}",
					press: this.onPressDelete.bind(this)
				}),

				new Button({
					enabled: true,
					visible: true,
					text: "",
					type: "Default",
					icon: "{i18n>iRefresh}",
					press: this.onPressRefresh.bind(this)
				})
			];
			this._oSmartTable = new SmartTable({
				entitySet: "zjblessons_base_" + sEntity,
				editable: false,
				smartFilterId: "sf" + sEntity,
				tableType: "Table",
				useExportToExcel: true,
				editTogglable: false,
				useVariantManagement: false,
				useTablePersonalisation: true,
				showVariantManagement: true,
				header: " ",
				showRowCount: true,
				enableAutoBinding: true,
				showFullScreenButton: true,
				visible: true,
				beforeRebindTable: this._onBeforeRebindTable.bind(this),
				customToolbar: new OverflowToolbar({
					design: "Transparent",
					content: aToolbarButtons

				})
			});

			this._oTable = this._oSmartTable.getTable();
			this._oTable.bindProperty("selectionMode", {
				path: "detailView>/table/selectionMode"
			});
			this._oSmartTable.setHeader(this.getResourceBundle().getText("tableHeader"));
			this._oTable.setSelectionMode("Single");
			this._oTable.setSelectionBehavior("Row");
			this._oTable.attachRowSelectionChange(this.onSelectionChange.bind(this));
			this.getModel("detailView").setProperty("/table/selectedItemsCount", 0);
			this.getModel("detailView").setProperty("/table/selectionMode", "Single");
			this.getModel("detailView").setProperty("/button/pressed/ChangeSelectionMode", false);
			this.getModel("detailView").setProperty("/button/pressed/ChangeVersionMode", false);

			var oRowActionTemplate = new sap.ui.table.RowAction({
				items: [
					new sap.ui.table.RowActionItem({
						icon: "{i18n>iEdit}",
						type: "Custom",
						text: "{i18n>ttEdit}",
						//	press: this.onUpdatePress.bind(this),
						visible: "{= ${detailView>/button/visible/Update} && !${detailView>/button/pressed/ChangeVersionMode} }"
					})
				]
			});

			this._oTable.setRowActionTemplate(oRowActionTemplate);
			this._oTable.setRowActionCount(1);
			this.getView().byId("page").setContent(this._oSmartTable);
			this.getView().byId("page").destroyHeaderContent();
			this.getView().byId("page").addHeaderContent(this._oSmartFilterBar);
		},

		onSelectionChange: function() {
			this.getModel("detailView").setProperty("/table/selectedItemsCount", this._oTable.getSelectedIndices().length);

		},
		_onBeforeRebindTable: function(oEvent) {

			if (oEvent) {
				var sFilterKey = this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode") ? "deactiveVersion" :
					"activeVersion",
					oFilter = this._mFilters[sFilterKey];
				oEvent.getParameter("bindingParams").filters.push(oFilter);
			}
		},
		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		// _bindView: function(sObjectPath) {
		// 	// Set busy indicator during view binding
		// 	var oViewModel = this.getModel("detailView");

		// 	// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
		// 	oViewModel.setProperty("/busy", false);

		// 	this.getView().bindElement({
		// 		path: sObjectPath,
		// 		events: {
		// 			change: this._onBindingChange.bind(this),
		// 			dataRequested: function() {
		// 				oViewModel.setProperty("/busy", true);
		// 			},
		// 			dataReceived: function() {
		// 				oViewModel.setProperty("/busy", false);
		// 			}
		// 		}
		// 	});
		// },

		// _onBindingChange: function() {
		// 	var oView = this.getView(),
		// 		oElementBinding = oView.getElementBinding();

		// 	// No data for the binding
		// 	if (!oElementBinding.getBoundContext()) {
		// 		this.getRouter().getTargets().display("detailObjectNotFound");
		// 		// if object could not be found, the selection in the master list
		// 		// does not make sense anymore.
		// 		this.getOwnerComponent().oListSelector.clearMasterListSelection();
		// 		return;
		// 	}

		// 	var sPath = oElementBinding.getPath(),
		// 		oResourceBundle = this.getResourceBundle(),
		// 		oObject = oView.getModel().getObject(sPath),
		// 		sObjectId = oObject.MaterialID,
		// 		sObjectName = oObject.MaterialText,
		// 		oViewModel = this.getModel("detailView");

		// 	this.getOwnerComponent().oListSelector.selectAListItem(sPath);

		// 	oViewModel.setProperty("/shareSendEmailSubject",
		// 		oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
		// 	oViewModel.setProperty("/shareSendEmailMessage",
		// 		oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		// },

		_onMetadataLoaded: function() {
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/busy", true);
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		}

	});

});