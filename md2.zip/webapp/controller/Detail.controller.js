sap.ui.define([
	"md2/md2/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"md2/md2/model/formatter",
	"sap/m/MessageToast",
	"sap/ui/comp/smarttable/SmartTable",
	"sap/ui/comp/smartfilterbar/SmartFilterBar",
	"sap/m/OverflowToolbar",
	"sap/m/ToolbarSpacer",
	"sap/m/OverflowToolbarButton",
	"sap/m/OverflowToolbarToggleButton",
	"sap/m/ObjectStatus",
	"sap/m/Button",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, formatter, MessageToast, SmartTable, SmartFilterBar, OverflowToolbar, ToolbarSpacer,
	OverflowToolbarButton, OverflowToolbarToggleButton, ObjectStatus, Button, Filter, FilterOperator, Fragment, MessageBox) {
	"use strict";

	return BaseController.extend("md2.md2.controller.Detail", {

		formatter: formatter,
		_mFilters: {
			activeVersion: new Filter("Version", FilterOperator.NE, "D"),
			deactiveVersion: new Filter("Version", FilterOperator.EQ, "D")
		},

		_oViewModel: new JSONModel({
			button: {
				visible: {
					Create: true,
					Update: true,
					DeactivateDelete: true,
					Restore: true,
					Refresh: true,
					Copy: true,
					ChangeSelectionMode: true,
					ChangeVersionMode: true
				},
				pressed: {
					ChangeSelectionMode: false,
					ChangeVersionMode: false
				}
			},
			table: {
				selectionMode: "Single",
				selectedItemsCount: 0
			},
			dialog: {
				title: "",
				inputValue: "",
				mode: "",
				updatePath: "",
				label: "",
				nameField: "",
				idField: ""
			},
			entity: {
				name: ""
			}
		}),

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(this._oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},
		_onObjectMatched: function(oEvent) {
			var sEntity = oEvent.getParameter("arguments").entity;
			this.getModel("detailView").setProperty("/entity/name", sEntity.slice(0, -1).concat("Text"));

			console.log("Entity - " + this.getModel("detailView").getProperty("/entity/name"));

			this.getModel().metadataLoaded().then(function() {
				this.byId("thDetail").setText(this.getModel("i18n").getResourceBundle().getText("t" + sEntity));
				this._loadTable(sEntity);
				this.getModel("detailView").setProperty("/dialog/idField", this._oSmartTable.getEntitySet().slice(16, -1) + "ID");
				this.getModel("detailView").setProperty("/dialog/nameField", this._oSmartTable.getEntitySet().slice(16, -1) + "Text");

			}.bind(this));
		},
		onPressChangeSelectionMode: function(oEvent) {
			this.getModel("detailView").setProperty("/table/selectionMode", oEvent.getParameter("pressed") ? "Multi" : "Single");
			oEvent.getParameter("pressed") ? MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastMultiSelectON")) :
				MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastMultiSelectOFF"));
		},
		onPressDeactivateMode: function(oEvent) {
			this._oSmartTable.rebindTable();
			oEvent.getParameter("pressed") ? MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastDeactivatedGoods")) :
				MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tToastActivatedGoods"));
		},
		onPressDelete: function(oEvent) {
			var that = this;
			var aSelectedContext = this._oTable.getSelectedIndices().map(function(iSelectedIndex) {
				return this._oTable.getContextByIndex(iSelectedIndex);
			}.bind(this));
			if (this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode")) {
				MessageBox.confirm(this.getModel("i18n").getResourceBundle().getText("msgConfirmDelete"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aSelectedContext.forEach(function(oContext) {
								that.getModel().remove(oContext.getPath(), {
									success: function() {
										MessageToast.show(that.getModel("i18n").getResourceBundle().getText("msgSuccessDelete"));
									}
								});
							});
						}
					}
				});
			} else {
				MessageBox.confirm(this.getModel("i18n").getResourceBundle().getText("msgConfirmDeactivate"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aSelectedContext.forEach(function(oContext) {
								that.getModel().setProperty(oContext.getPath() + "/Version", "D");
							});
							that.getModel().submitChanges({
								success: function() {
									MessageToast.show(that.getModel("i18n").getResourceBundle().getText("msgSuccessDeactivate"));
								}
							});
						}
					}
				});
			}
		},

		onUpdatePress: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this.getModel("detailView").setProperty("/dialog/mode", "editMode");
			this.getModel("detailView").setProperty("/dialog/title", "Edit item");

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("md2.md2.view.fragments.AddEditDialog", this);
				this.getView().addDependent(this._oDialog);
				this._oDialog.setBindingContext(oContext);

				this._oDialog.open();
			}
			MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tDialogUpdateItem"));

		},
		onPressAdd: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this.getModel("detailView").setProperty("/dialog/mode", "addMode");

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("md2.md2.view.fragments.AddEditDialog", this);

				this.getView().addDependent(this._oDialog);
				this._oDialog.setBindingContext(oContext);

				this._oDialog.open();
			}
			MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tDialogCreate"));
		},
		onPressOKUpdate: function(oEvent) {
			var sEntity = this.getModel("detailView").getProperty("/entity/name");
			var sPath = this._oDialog.getBindingContext().getPath();
			if (sEntity === "GroupText") {
					this.getModel().update(sPath, {
				GroupText: this._oDialog.getContent()[1].getValue()
			}, {
				success: function(e) {
					MessageToast.show("Edited OK");
				},
				error: function(e) {
					MessageToast.show("Editing Error");
				}
			});
			}
			if (sEntity === "SubGroupText") {
					this.getModel().update(sPath, {
				SubGroupText: this._oDialog.getContent()[1].getValue()
			}, {
				success: function(e) {
					MessageToast.show("Edited OK");
				},
				error: function(e) {
					MessageToast.show("Editing Error");
				}
			});
			}
			if (sEntity === "PlantText") {
					this.getModel().update(sPath, {
				PlantText: this._oDialog.getContent()[1].getValue()
			}, {
				success: function(e) {
					MessageToast.show("Edited OK");
				},
				error: function(e) {
					MessageToast.show("Editing Error");
				}
			});
			}
			if (sEntity === "RegionText") {
					this.getModel().update(sPath, {
				RegionText: this._oDialog.getContent()[1].getValue()
			}, {
				success: function(e) {
					MessageToast.show("Edited OK");
				},
				error: function(e) {
					MessageToast.show("Editing Error");
				}
			});
			}
			this._oDialog.destroy();
			this._oDialog = null;

		},
		onPressOKCreate: function(oEvent) {
			var oContext;
			var sEntity = this.getModel("detailView").getProperty("/entity/name");
			if (sEntity === "GroupText") {
				oContext = this.getModel().createEntry(this._oSmartTable.getEntitySet(), {
					properties: {
						GroupText: this._oDialog.getContent()[0].getValue(),
						GroupID: "",
						Version: "A",
						Language: "RU"
					}
				});
				this._oDialog.setBindingContext(oContext);
			}
			if (sEntity === "SubGroupText") {
				oContext = this.getModel().createEntry(this._oSmartTable.getEntitySet(), {
					properties: {
						SubGroupText: this._oDialog.getContent()[0].getValue(),
						SubGroupID: "",
						Version: "A",
						Language: "RU"
					}
				});
				this._oDialog.setBindingContext(oContext);

			}
			if (sEntity === "PlantText") {

				oContext = this.getModel().createEntry(this._oSmartTable.getEntitySet(), {
					properties: {
						PlantText: this._oDialog.getContent()[0].getValue(),
						PlantID: "",
						Version: "A",
						Language: "RU"
					}
				});
				this._oDialog.setBindingContext(oContext);

			}
			if (sEntity === "RegionText") {

				oContext = this.getModel().createEntry(this._oSmartTable.getEntitySet(), {
					properties: {
						RegionText: this._oDialog.getContent()[0].getValue(),
						RegionID: "",
						Version: "A",
						Language: "RU"
					}
				});
				this._oDialog.setBindingContext(oContext);

			}

			this.getModel().submitChanges({
				success: function() {
					MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msgAddGood"));
				}.bind(this)
			});
			this._oDialog.destroy();
			this._oDialog = null;
		},
		onPressRestore: function(oEvent) {
			var that = this;
			var aSelectedContext = this._oTable.getSelectedIndices().map(function(iSelectedIndex) {
				return this._oTable.getContextByIndex(iSelectedIndex);
			}.bind(this));

			if (this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode")) {
				MessageBox.confirm(this.getModel("i18n").getResourceBundle().getText("msgConfirmRestore"), {
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							aSelectedContext.forEach(function(oContext) {
								that.getModel().setProperty(oContext.getPath() + "/Version", "A");
							});
							that.getModel().submitChanges({
								success: function() {
									MessageToast.show(that.getModel("i18n").getResourceBundle().getText("msgSuccessRestore"));
								}
							});
						}
					}
				});
			}
		},

		onPressRefresh: function(oEvent) {
			this._oSmartTable.rebindTable(true);
			MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msgRefreshTable"));
		},
		
		onPressCancelDialog: function(oEvent) {
			this.getModel().resetChanges();
			this._oDialog.destroy();
			this._oDialog = null;
			MessageToast.show(this.getModel("i18n").getResourceBundle().getText("tDialogCanceled"));
		},
		_loadTable: function(sEntity) {

			this._oSmartFilterBar = new SmartFilterBar({
				id: "sf" + sEntity,
				entitySet: "zjblessons_base_" + sEntity,
				liveMode: true,
				enableBasicSearch: false,
				useToolbar: true
			});
			var aToolbarButtons = [

				new OverflowToolbarToggleButton({
					enabled: true,
					visible: "{detailView>/button/visible/ChangeSelectionMode}",
					text: "{i18n>tMultiSelectToogleButton}",
					type: "Default",
					icon: "{i18n>iMultiSelect}",
					press: this.onPressChangeSelectionMode.bind(this),
					pressed: "{detailView>/button/pressed/ChangeSelectionMode}",
					tooltip: "{i18n>tButtonTipMultiselectMode}"
				}),
				new OverflowToolbarToggleButton({
					enabled: true,
					visible: "{detailView>/button/visible/ChangeVersionMode}",
					text: "{i18n>tShowDeactivatedButton}",
					type: "Reject",
					icon: "{i18n>iCircle1}",
					activeIcon: "{i18n>iActive}",
					press: this.onPressDeactivateMode.bind(this),
					pressed: "{detailView>/button/pressed/ChangeVersionMode}",
					tooltip: "{i18n>tButtonTipDeactivateMode}"
				}),
				new ToolbarSpacer(),
				new Button({
					enabled: "{detailView>/button/pressed/ChangeVersionMode}",
					visible: "{detailView>/button/pressed/ChangeVersionMode}",
					text: "",
					type: "Default",
					icon: "{i18n>iRestore}",
					tooltip: "{i18n>tButtonTipRestore}",
					press: this.onPressRestore.bind(this)
				}),
				new Button({
					enabled: "{= !${detailView>/button/pressed/ChangeVersionMode}}",
					visible: "{= !${detailView>/button/pressed/ChangeVersionMode}}",
					text: "",
					type: "Default",
					icon: "{i18n>iAdd}",
					tooltip: "{i18n>tButtonTipAdd}",
					press: this.onPressAdd.bind(this)
				}),
				new Button({
					enabled: true,
					visible: true,
					text: "",
					type: "Default",
					icon: "{i18n>iDelete}",
					tooltip: "{i18n>tButtonTipDelete}",
					press: this.onPressDelete.bind(this)
				}),
				new Button({
					enabled: true,
					visible: true,
					text: "",
					type: "Default",
					icon: "{i18n>iRefresh}",
					press: this.onPressRefresh.bind(this)
				})
			];
			this._oSmartTable = new SmartTable({
				entitySet: "zjblessons_base_" + sEntity,
				editable: false,
				smartFilterId: "sf" + sEntity,
				tableType: "Table",
				useExportToExcel: true,
				editTogglable: false,
				useVariantManagement: false,
				useTablePersonalisation: true,
				showVariantManagement: true,
				header: " ",
				showRowCount: true,
				enableAutoBinding: true,
				showFullScreenButton: true,
				visible: true,
				beforeRebindTable: this._onBeforeRebindTable.bind(this),
				customToolbar: new OverflowToolbar({
					design: "Transparent",
					content: aToolbarButtons

				})
			});

			this._oTable = this._oSmartTable.getTable();
			this._oTable.bindProperty("selectionMode", {
				path: "detailView>/table/selectionMode"
			});
			this._oSmartTable.setHeader(this.getResourceBundle().getText("tableHeader"));
			this._oTable.setSelectionMode("Single");
			this._oTable.setSelectionBehavior("Row");
			this._oTable.attachRowSelectionChange(this.onSelectionChange.bind(this));
			this.getModel("detailView").setProperty("/table/selectedItemsCount", 0);
			this.getModel("detailView").setProperty("/table/selectionMode", "Single");
			this.getModel("detailView").setProperty("/button/pressed/ChangeSelectionMode", false);
			this.getModel("detailView").setProperty("/button/pressed/ChangeVersionMode", false);
			
			this._oTable.addColumn(
				new sap.ui.table.Column({
					template: new sap.m.Input({
						value: "{"+this.getModel("detailView").getProperty("/entity/name").slice(0,-4)+"ID"+"}"
					}),
					label: new sap.m.Label({
						text: this.getModel("detailView").getProperty("/entity/name").slice(0,-4)+"ID"
					}),
					customData: [
						new sap.ui.core.CustomData({
							key: "p13nData",
							value: {
								"columnKey": this.getModel("detailView").getProperty("/entity/name").slice(0,-4)+"ID",
								"leadingProperty": this.getModel("detailView").getProperty("/entity/name").slice(0,-4)+"ID",
								columnIndex: "3"
							}
						})
						]
				})
				);
			

			var oRowActionTemplate = new sap.ui.table.RowAction({
				items: [
					new sap.ui.table.RowActionItem({
						icon: "{i18n>iEdit}",
						type: "Custom",
						text: "{i18n>ttEdit}",
						press: this.onUpdatePress.bind(this),
						visible: "{= ${detailView>/button/visible/Update} && !${detailView>/button/pressed/ChangeVersionMode} }"
					})
				]
			});

			this._oTable.setRowActionTemplate(oRowActionTemplate);
			this._oTable.setRowActionCount(1);
			this.getView().byId("page").setContent(this._oSmartTable);
			this.getView().byId("page").destroyHeaderContent();
			this.getView().byId("page").addHeaderContent(this._oSmartFilterBar);
		},

		onSelectionChange: function() {
			this.getModel("detailView").setProperty("/table/selectedItemsCount", this._oTable.getSelectedIndices().length);

		},
		_onBeforeRebindTable: function(oEvent) {

			if (oEvent) {
				var sFilterKey = this.getModel("detailView").getProperty("/button/pressed/ChangeVersionMode") ? "deactiveVersion" :
					"activeVersion",
					oFilter = this._mFilters[sFilterKey];
				oEvent.getParameter("bindingParams").filters.push(oFilter);
			}
		},
		_onMetadataLoaded: function() {
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/busy", true);
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		}

	});

});