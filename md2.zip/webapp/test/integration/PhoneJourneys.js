/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"md2/md2/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"md2/md2/test/integration/pages/App",
	"md2/md2/test/integration/pages/Browser",
	"md2/md2/test/integration/pages/Master",
	"md2/md2/test/integration/pages/Detail",
	"md2/md2/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "md2.md2.view."
	});

	sap.ui.require([
		"md2/md2/test/integration/NavigationJourneyPhone",
		"md2/md2/test/integration/NotFoundJourneyPhone",
		"md2/md2/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});